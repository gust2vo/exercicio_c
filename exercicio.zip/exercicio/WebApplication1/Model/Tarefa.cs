namespace Program.Model
{
    class Tarefa
    {
        public Guid id {get; set;}
        public String name {get; set;}
        
        public Boolean status {get; set;}

        public Tarefa(Guid id, String name, Boolean status)
        {
            this.id = id;
            this.name = name;
            this.status = status;
        }
    }
}