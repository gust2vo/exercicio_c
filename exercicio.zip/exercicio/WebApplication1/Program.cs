using NSwag.AspNetCore;
using Program.Model;
class HelloWeb
{
    static void Main(string[] args)
    {
        WebApplicationBuilder builder = WebApplication.CreateBuilder(args);
        builder.Services.AddEndpointsApiExplorer();
        builder.Services.AddOpenApiDocument(config =>
        {
            config.DocumentName = "TodoAPI";
            config.Title = "TodoAPI v1";
            config.Version = "v1";
        });

        WebApplication app = builder.Build();
        if (app.Environment.IsDevelopment())
        {
            app.UseOpenApi();
            app.UseSwaggerUi(config =>
            {
                config.DocumentTitle = "Icecream API";
                config.Path = "/swagger";
                config.DocumentPath = "/swagger/{documentName}/swagger.json";
                config.DocExpansion = "list";
            });
        }   

        List<Tarefa> tasks = new()
        {
            new Tarefa(Guid.NewGuid(), "Estudar", true),
            new Tarefa(Guid.NewGuid(), "Ler", true),
            new Tarefa(Guid.NewGuid(), "Fazer relatorio", false)
        };

        app.MapGet("/tasks", () => {
            return Results.Ok(tasks);
        });

        app.MapGet("/tasks/complete", () => {
            var completedTasks = new List<Tarefa>();
                foreach (var task in tasks)
                {
                    if (task.status == true)
                    {
                        completedTasks.Add(task);
                    }
                }
            return Results.Ok(completedTasks);
        });

        app.MapGet("/tasks/id", (Guid taskId)  =>{

            foreach (var task in tasks) 
            {
                if (task.id == taskId)
                {   
                    return Results.Ok(task);
                }

            }
            return Results.NotFound();
        });

        app.MapPost("/tasks/create", (string name) =>{
            var newTask = new Tarefa(Guid.NewGuid(), name, true);
            tasks.Add(newTask);
            
            Results.Ok(newTask);
        });
       
        app.MapPut("/tasks/update", (Tarefa inputTask) =>{
             if (inputTask is null) return Results.NotFound();

            foreach (var task in tasks)
            {
                if (task.id == inputTask.id)
                {
                    task.name = inputTask.name;
                    task.status = inputTask.status;
                    return Results.Ok(task);
                }
                
            }
            return Results.NotFound();
        });

        app.MapDelete("tasks/delete", (Guid id) =>{
            foreach (var task in tasks)
            {
                if (task.id.CompareTo(id) == 0)
                {
                    tasks.Remove(task);
                    return Results.Ok(task);
                }
            }
            return Results.NotFound();
        });     

            

        app.Run();
    }
}

